<?php
if ( class_exists( 'RWMB_Field' )  ) {
/**
	 * The background field.
	 *
	 * @package Meta Box
	 */

	/**
	 * The Background field.
	 */
	class RWMB_Typography_Field extends RWMB_Field {
		/**
		 * Enqueue scripts and styles.
		 */
		public static function admin_enqueue_scripts() {
			wp_enqueue_style( 'rwmb-background', RWMB_CSS_URL . 'background.css', '', RWMB_VER );

			RWMB_Color_Field::admin_enqueue_scripts();
			RWMB_File_Input_Field::admin_enqueue_scripts();
		}

		/**
		 * Get field HTML.
		 *
		 * @param mixed $meta  Meta value.
		 * @param array $field Field settings.
		 *
		 * @return string
		 */
		public static function html( $meta, $field ) {
			$meta = wp_parse_args(
				$meta,
				include XSMART_ADMIN_DIR. '/xsmart-config/mb-typography-type-config.php'
			);
			$inline_typo = true;
			if( isset($field['inline_typo']) ){
				$inline_typo = $field['inline_typo'];
			}

			$output = '';

			$args = array(
					'tag' => 'Tag',
					'tag_size' => 'Size',					
					'id' => 'ID',					
					'class' => 'Class',					
				);
			$output .= self::__class_html($meta, $field, $args);

			$args = array(
					'font_family' => 'Font family',
					'text_color' => 'Color',
					'text_bg' => 'Background',	
					'text_align' => 'Align',	
				);
			$output .= self::__class_html($meta, $field, $args);

			if( $inline_typo ):
			$output .= '<p class="inline-typo-heading">Inline style</p>';

			$args = array(					
					'font-size' => 'font-size',
					'line-height' => 'line-height',
					'font-weight' => 'font-weight',
					'font-style' => 'font-style',	
				);
			$output .= self::__class_html($meta, $field, $args);

			$args = array(					
					'letter-spacing' => 'letter-spacing',
					'text-decoration' => 'text-decoration',
					'text-transform' => 'text-transform',	
					'font-variant' => 'font-variant',
				);
			$output .= self::__class_html($meta, $field, $args);
			endif;
			

			return $output;
		}


		public static function __select_html($key, $meta, $field, $options, $placeholder){
			$options_field = RWMB_Select_Field::normalize(
							array(
								'type'       => 'select',
								'id'         => "{$field['id']}_{$key}",
								'field_name' => "{$field['field_name']}[{$key}]",
								'placeholder' => $placeholder,
								'options'     => $options,
								'columns' => 6,
							)
						);
			return RWMB_Select_Field::html( $meta[$key], $options_field );
		}

		public static function __class_html($meta, $field, $args = array()){
			$output = '';
			if( !empty($args) ):
				$output = '<div class="rwmb-background-row">';

				foreach ($args as $field_id => $placeholder) {	
					$options = self::get_config($field_id);				
					$output .= self::__select_html($field_id, $meta, $field, $options, $placeholder);					
				}
				$output .= '</div><!-- .rwmb-background-row -->';
				
			endif;
			return $output;
		}

		/**
	 * If field 'font_family' is used this is list of fonts available
	 * To modify this list, you should use add_filter('get_fonts_filter','your_custom_function');
	 * filter: get_fonts_filter - to modify list of fonts
	 * @return array list of fonts
	 */
	public function get_web_safe_fonts() {
		// this is "Web Safe FONTS" from w3c: http://www.w3schools.com/cssref/css_websafe_fonts.asp
		$web_fonts = array(					
				'primary'       => 'Primary font',					
				'secondary'       => 'Secondary font',
			);		
    	

		return apply_filters( 'get_web_safe_fonts', $web_fonts );
	}

	public function get_font_family_name($value){
		$google_fonts  = get_theme_mod( 'ot_google_fonts', array() );		
		$family = isset($google_fonts[$value])? $google_fonts[$value]['family'] : '';

		$default = array(
            'roboto'     => 'Roboto',
            'montserrat'     => 'Montserrat',
            'arial'     => 'Arial',
            'georgia'   => 'Georgia',
            'helvetica' => 'Helvetica',
            'palatino'  => 'Palatino',
            'tahoma'    => 'Tahoma',
            'times'     => 'Times New Roman',
            'trebuchet' => 'Trebuchet',
            'verdana'   => 'Verdana'
          );
		if( ('' == $family) && isset($default[$value]) ){
			$family = $default[$value];
		}


		return $family;
	}

	/**
	 * If 'tag' field used this is list of allowed tags
	 * To modify this list, you should use add_filter('get_allowed_tags','your_custom_function');
	 * filter: get_allowed_tags - to modify list of allowed tags by default
	 * @return array list of allowed tags
	 */
	public function get_allowed_tags() {
		$allowed_tags = array(
        __('Heading 1', 'xsmart') => 'h1',
        __('Heading 2', 'xsmart') => 'h2',
        __('Heading 3', 'xsmart') => 'h3',
        __('Heading 4', 'xsmart') => 'h4',
        __('Heading 5', 'xsmart') => 'h5',
        __('Heading 6', 'xsmart') => 'h6',
        __('Paragraph', 'xsmart') => 'p',
        __('Span', 'xsmart') => 'span',
        __('Div', 'xsmart') => 'div',
    );

		return apply_filters( 'get_allowed_tags', array_flip($allowed_tags) );

	}

	public function get_allowed_inner_tags(){
		$allowed_tags = array(
		__('Choose Inner tag', 'xsmart') => '',
		__('Span', 'xsmart') => 'span',
        __('Paragraph', 'xsmart') => 'p', 
        __('Small', 'xsmart') => 'small',       
        __('Strong', 'xsmart') => 'strong', 
         __('Underline', 'xsmart') => 'u',      
        __('Blockquote', 'xsmart') => 'blockquote',               
        __('Address', 'xsmart') => 'address',       
        __('em', 'xsmart') => 'em',       
        __('Del', 'xsmart') => 'del',       
        __('Mark', 'xsmart') => 'mark',       
        __('S', 'xsmart') => 's',       
        __('Ins', 'xsmart') => 'ins',       
        __('Code', 'xsmart') => 'code',       
        __('Pre', 'xsmart') => 'pre',       
        __('Var', 'xsmart') => 'var',       
        __('kbd', 'xsmart') => 'kbd',       
        __('samp', 'xsmart') => 'samp',   
         __('Footer', 'xsmart') => 'footer',     
             
    );

		return apply_filters( 'get_allowed_inner_tags', array_flip($allowed_tags) );

	}

	/**
	 * Tag size class array
	 * @return array
	 */
	public function size_class_options(){
	    $allowed_size = array(
	        __('Extra large', 'xsmart') => 'xl',
	        __('Large', 'xsmart') => 'lg',
	        __('Medium', 'xsmart') => 'md',
	        __('Small', 'xsmart') => 'sm',
	        __('Extra small', 'xsmart') => 'xs',
	    );

	    return apply_filters( 'get_allowed_size_class', array_flip($allowed_size) );
	}

	/**
	 * Recognized font weights
	 * @return array
	 */
	public function font_weights_options(){
	   $array = array(
	      'normal'    => 'Normal',
	      'bold'      => 'Bold',
	      'bolder'    => 'Bolder',
	      'lighter'   => 'Lighter',
	      '100'       => '100',
	      '200'       => '200',
	      '300'       => '300',
	      '400'       => '400',
	      '500'       => '500',
	      '600'       => '600',
	      '700'       => '700',
	      '800'       => '800',
	      '900'       => '900',
	      'inherit'   => 'Inherit'
	    );

	    return apply_filters( 'font_container_font_weights_options', $array );
	}

	/**
	 * Recognized letter spacing
	 * @return array
	 */
	public function letter_spacing_options(){
	   $range = self::_range( 
	      apply_filters( 'letter_spacing_low_range', -0.1 ), 
	      apply_filters( 'letter_spacing_high_range', 0.1 ), 
	      apply_filters( 'letter_spacing_range_interval', 0.01 )
	    );
    	$unit = apply_filters( 'letter_spacing_unit_type', 'em' );   

    	$array = array( '' => 'Letter spacing' );
	    foreach( $range as $k => $v ) {
	      $array[$v . $unit] = $v . $unit;
	    } 

	   $array = array_flip($array);

	    return apply_filters( 'font_container_font_weights_options', array_flip($array) );
	}

	/**
	 * Recognized Font sizes
	 * @return array
	 */
	public function font_sizes_options(){
	   $range = self::_range( 
	      apply_filters( 'font_size_low_range', 0 ), 
	      apply_filters( 'font_size_high_range', 15 ), 
	      apply_filters( 'font_size_range_interval', .1 )
	    );
    	$unit = apply_filters( 'font_size_unit_type', 'rem' );   

    	$array = array( '' => 'Font size' );
	    foreach( $range as $k => $v ) {
	      $array[$v . $unit] = $v . $unit;
	    } 

	   $array = array_flip($array);

	    return apply_filters( 'font_container_font_sizes_options', array_flip($array) );
	}

	/**
	 * Recognized text_decorations
	 * @return array
	 */
	public function text_decorations_options(){   
		$array = array( 
			'blink'         => 'Blink',
			'inherit'       => 'Inherit',
			'line-through'  => 'Line Through',
			'none'          => 'None',
			'overline'      => 'Overline',
			'underline'     => 'Underline'
		 );	   
		
		return apply_filters( 'font_container_text_decorations_options', $array );
	}

	/**
	 * Recognized text_transformations
	 * @return array
	 */
	public function text_transformations_options(){   
		$array = array( 
			'capitalize'  => 'Capitalize',
			'inherit'     => 'Inherit',
			'lowercase'   => 'Lowercase',
			'none'        => 'None',
			'uppercase'   => 'Uppercase'
		 );	   
		
		return apply_filters( 'font_container_text_transformations_options', $array );
	}

	/**
	 * Recognized font_variants
	 * @return array
	 */
	public function font_variants_options(){   
		$array = array( 
			'normal'      => 'Normal',
      		'small-caps'  => 'Small Caps',
      		'inherit'     => 'Inherit'
		 );	   
		
		return apply_filters( 'font_container_font_variants_options', $array );
	}

	/**
	 * Recognized font_styles
	 * @return array
	 */
	public function font_styles_options(){   
		$array = array( 			
			'normal'  => 'Normal',
			'italic'  => 'Italic',
			'oblique' => 'Oblique',
			'inherit' => 'Inherit'
		 );	   
		
		return apply_filters( 'font_container_font_styles_options', $array );
	}

	/**
	 * Recognized line height
	 * @return array
	 */
	public function line_height_options(){
	   $range = self::_range( 
	      apply_filters( 'line_height_low_range', 0 ), 
	      apply_filters( 'line_height_high_range', 15 ), 
	      apply_filters( 'line_height_range_interval', .1 )
	    );
    	$unit = apply_filters( 'line_height_unit_type', 'rem' );   

    	$array = array( '' => 'line-height' );
	    foreach( $range as $k => $v ) {
	      $array[$v . $unit] = $v . $unit;
	    } 

	   $array = array_flip($array);

	    return apply_filters( 'font_container_line_height_options', array_flip($array) );
	}
	

	/**
	 * Color class array
	 * @return array
	 */
	public function get_allowed_colors(){
	    $allowed_color = include XSMART_ADMIN_DIR. '/xsmart-config/color-config.php';

	    return apply_filters( 'get_allowed_colors', $allowed_color );
	}

	/**
	 * Underline class array
	 * @return array
	 */
	public function uncerline_class_options(){
	    $allowed_color = array(
	        __('None', 'xsmart') => ''
	    );

	    if( function_exists('xsmartunderline_color_options') ){
	    	$allowed_color = array_merge($allowed_color, xsmartunderline_color_options());
	    }

	    return apply_filters( 'get_allowed_underline_class', $allowed_color );
	}

	/**
	 * Background class array
	 * @return array
	 */
	public function bg_class_options(){
	    $allowed_color = array(
	        __('None', 'xsmart') => ''
	    );

	    if( function_exists('xsmartbackground_options') ){
	    	$allowed_color = array_merge($allowed_color, xsmartbackground_options(true));
	    }

	    return apply_filters( 'get_allowed_bg_class', array_flip($allowed_color) );
	}

	/**
	 * Text align class array
	 * @return array
	 */
	public function align_class_options(){
	    $allowed_size = array(
                    'Left' => 'text-left',
                    'Center' => 'text-center',
                    'Right' => 'text-right',
                    'Justify' => 'text-justify',                    
                );

	    return apply_filters( 'get_allowed_align_class', array_flip($allowed_size) );
	}

	/**
	 * Text align class array
	 * @return array
	 */
	public function get_defined_class(){
	    $array = array(
                    'App version' => 'app-version',
                    'OS version' => 'os-version',
                    'Section id' => 'section-id',
                    'statistic-number' => 'statistic-number',                    
                    'price' => 'price',                    
                    'validity' => 'validity',                    
                    'pr-user' => 'pr-user',                    
                    'app-price' => 'app-price',                    
                    'app-rating' => 'app-rating',                    
                    'post-tag' => 'post-tag',                    
                    'price' => 'price',                    
                );

	    return apply_filters( 'get_defined_class', array_flip($array) );
	}

	/**
	 * defined id array
	 * @return array
	 */
	public function get_defined_id(){
	    $array = array(
                    'App version' => 'app-version',
                    'OS version' => 'os-version',
                    'Section id' => 'section-id',
                    'statistic-number' => 'statistic-number',                    
                    'price' => 'price',                    
                    'validity' => 'validity',                    
                    'pr-user' => 'pr-user',                    
                    'app-price' => 'app-price',                    
                    'app-rating' => 'app-rating',                    
                    'post-tag' => 'post-tag',                    
                    'price' => 'price',                    
                );

	    return apply_filters( 'get_defined_id', array_flip($array) );
	}

	public function _range( $start, $limit, $step = 1 ) {
	  if ( $step < 0 )
	    $step = 1;
	  $range = range( $start, $limit, $step );	 

	  foreach( $range as $k => $v ) {
	    if ( strpos( $v, 'E' ) ) {
	      $range[$k] = 0;
	    }
	  }
	  return $range;
	}

	
	public static function font_container_inline_options() {
		return array( 'line-height', 'font-size', 'font-variant', 'font-weight', 'text-decoration', 'text-transform', 'letter-spacing', 'font-style');
	}

	public static function font_container_class_options() {
		return array('font_family','text_color', 'tag_size', 'text_align', 'text_bg', 'text_underline', 'extra_class', 'css_class', 'class');
	}

	public static function font_container_options(){
		return array_merge(self::font_container_inline_options(), self::font_container_class_options());
	}

		/**
		 * Format a single value for the helper functions. Sub-fields should overwrite this method if necessary.
		 *
		 * @param array    $field   Field parameters.
		 * @param array    $value   The value.
		 * @param array    $args    Additional arguments. Rarely used. See specific fields for details.
		 * @param int|null $post_id Post ID. null for current post. Optional.
		 *
		 * @return string
		 */
		public static function format_single_value( $field, $value, $args, $post_id ) {
			if ( empty( $value ) ) {
				return '';
			}
			$output = '';
			$value  = array_filter( $value );
			foreach ( $value as $key => $subvalue ) {
				$subvalue = 'image' === $key ? 'url(' . esc_url( $subvalue ) . ')' : $subvalue;
				$output  .= 'background-' . $key . ': ' . $subvalue . ';';
			}
			return $output;
		}

		public static function get_config($option_name = ''){
			$config = array(
				'tag' => self::get_allowed_tags(),
				'tag_size' => self::size_class_options(),
				'inner_tag' => self::get_allowed_inner_tags(),
				'text_color' => self::get_allowed_colors(),
				'font_family' => self::get_web_safe_fonts(),
				'text_bg' => self::get_allowed_colors(),
				'text_underline' => self::get_allowed_colors(),
				'text_align' => self::align_class_options(),
				'class' => self::get_defined_class(),	
				'id' => self::get_defined_id(),		
				// inline
				'font-size' => self::font_sizes_options(),
				'font-style' => self::font_styles_options(),
				'font-variant' => self::font_variants_options(),
				'font-weight' => self::font_weights_options(),
				'letter-spacing' => self::letter_spacing_options(),
				'text-decoration' => self::text_decorations_options(),
				'text-transform' => self::text_transformations_options(),
				'line-height' => self::line_height_options(),				
				
				// additional
				'extra_class' => '',				
				'css_class' => '',
				'all_classes' => '',
				'inline_css' => '',				
				'wrapper_attributes' => '',				
			);

			if( ($option_name != '') && isset($config[$option_name]) ){
				return $config[$option_name];
			}else{
				return $config;
			}
		}

		public static function is_valid_field_by_typo($field_id, $args){
			if( ($field_id == '') && empty($args) ) return false;
			if(!isset($args[$field_id])) return false;
			return true;
		}

		public static function is_valid_field_typo_settings($field_id, $args){
			if( ($field_id == '') && empty($args) ) return false;
			if(!isset($args[$field_id.'_typo'])) return false;
			return true;
		}

		/**
		* @return array
		*/
		public static function get_valid_typo_attributes($args){
			if( !empty($args) ){
				extract($args);
				foreach ($args as $key => $value) {
					if($key == 'tag_size'){
						$format = _xsmart_get_config($key, 'classes');   
				    	$args[$key] = $format? sprintf($format, $tag, $value) : '';
					}else{
						$format = _xsmart_get_config($key, 'classes');   
				    	$args[$key] = $format? sprintf($format, $value) : $value;
					}
					
				}
			}
			return $args;
		}

		/**
		* @return string
		*/
		public static function get_typo_attributes($args){
			$id = '';
			if( empty($args) ) return '';
			$attributes = array();
			$classes = array();

			$args = self::get_valid_typo_attributes($args);

			$class_options = self::font_container_class_options();
			foreach ($args as $key => $value) {
				if( in_array($key, $class_options) ){
					$classes[] = $value;
				}				
			}

			$attributes['class'] = implode(' ', array_filter($classes)); 
			$attributes['id'] = $id;

			$attributes = array_filter($attributes);

			$output = '';
			if( !empty($attributes) ){				
				foreach ($attributes as $key => $value) {
					$output .= " {$key}='{$value}'";
				}
			}
			return $output;

		}

		/**
		* @return string
		*/
		public static function get_field_value_by_typo( $output, $args ){
			$tag = $attributes = $id = '';
			$args = array_filter($args);
			$attributes = self::get_typo_attributes($args);
			extract($args);				
			if( ($tag != '') && array_key_exists($tag, self::get_config('tag'))){
				$output = "<{$tag}{$attributes}>{$output}</{$tag}>";				
			}			
			return $output;
		}
	}
}



