<?php

add_action(
	'init',
	function() {
		if ( class_exists( 'MB_Custom_Table_API' ) ) {
			MB_Custom_Table_API::create(
				'wp_test',
				array(
					'col1' => 'TEXT NOT NULL',
					'col2' => 'TEXT NOT NULL',
					'col3' => 'TEXT NOT NULL',
				)
			);
		}
	}
);

add_filter(
	'rwmb_meta_boxes',
	function( $meta_boxes ) {
		$meta_boxes[] = array(
			'title'        => 'Test custom table clone',
			'storage_type' => 'custom_table',
			'table'        => 'wp_test',
			'fields'       => array(
				array(
					'name'  => 'Col 1',
					'id'    => 'col1',
					'type'  => 'text',
					'clone' => true,
					'std'   => array( 'Value 1', 'Value 2' ),
				),
			),
		);

		return $meta_boxes;
	}
);
