<?php

add_action(
	'init',
	function() {
		if ( class_exists( 'MB_Custom_Table_API' ) ) {
			MB_Custom_Table_API::create(
				'wp_test',
				array(
					'col1' => 'TEXT NOT NULL',
					'col2' => 'TEXT NOT NULL',
					'col3' => 'TEXT NOT NULL',
				)
			);
		}
	}
);

add_filter(
	'rwmb_meta_boxes',
	function( $meta_boxes ) {
		$prefix = 'mb_';

		$meta_boxes[] = array(
			'title'        => 'Test custom table',
			'storage_type' => 'custom_table',
			'table'        => 'wp_test',
			'fields'       => array(
				/*
				array(
					'name'             => 'Col 1',
					'id'               => 'col1',
					'type'             => 'text',
				),*/

				/*
				array(
					'name'             => 'Col 1',
					'id'               => 'col1',
					'type'             => 'text',
					'clone'            => true,
					'std'              => array( 'Value 1', 'Value 2' ),
				),*/

				/*
				// CHECKBOX
				array(
					'name' => esc_html__( 'Checkbox', 'your-prefix' ),
					'id'   => 'col1',
					'type' => 'checkbox',
					// Value can be 0 or 1
					'std'  => 1,
				),*/

				/*
				// RADIO BUTTONS
				array(
					'name'    => esc_html__( 'Radio', 'your-prefix' ),
					'id'      => 'col1',
					'type'    => 'radio',
					// Array of 'value' => 'Label' pairs for radio options.
					// Note: the 'value' is stored in meta field, not the 'Label'
					'options' => array(
						'value1' => esc_html__( 'Label1', 'your-prefix' ),
						'value2' => esc_html__( 'Label2', 'your-prefix' ),
					),
				),*/

				[
					'id'     => 'col1',
					'type'   => 'group',
					'clone'  => true,
					'fields' => [
						[
							'name'  => 'Text',
							'id'    => 'text5',
							'type'  => 'text',
							'clone' => true,
						],
					],
				],

				// SELECT BOX
				/*
				array(
					'name'        => esc_html__( 'Select', 'your-prefix' ),
					'id'          => 'col1',
					'type'        => 'select',
					// Array of 'value' => 'Label' pairs for select box
					'options'     => array(
						'value1' => esc_html__( 'Label1', 'your-prefix' ),
						'value2' => esc_html__( 'Label2', 'your-prefix' ),
					),
					// Select multiple values, optional. Default is false.
					'multiple'    => false,
					'std'         => 'value2',
					'placeholder' => esc_html__( 'Select an Item', 'your-prefix' ),
				),*/

				// PASSWORD
				/*
				array(
					'name' => esc_html__( 'Password', 'your-prefix' ),
					'id'   => 'col1',
					'type' => 'password',
				),*/

				/*
				// TEXTAREA
				array(
					'name' => esc_html__( 'Textarea', 'your-prefix' ),
					'desc' => esc_html__( 'Textarea description', 'your-prefix' ),
					'id'   => 'col1',
					'type' => 'textarea',
					'cols' => 20,
					'rows' => 3,
				),*/

				array(
					'name' => 'Col 2',
					'id'   => 'col2',
					'type' => 'text',
					'std'  => 'Col 2 default value',
				),
				// WYSIWYG/RICH TEXT EDITOR
				array(
					'name'    => esc_html__( 'WYSIWYG / Rich Text Editor', 'your-prefix' ),
					'id'      => 'col3',
					'type'    => 'wysiwyg',
					// Set the 'raw' parameter to TRUE to prevent data being passed through wpautop() on save
					'raw'     => false,
					'std'     => esc_html__( 'WYSIWYG default value', 'your-prefix' ),

					// Editor settings, see wp_editor() function: look4wp.com/wp_editor
					'options' => array(
						'textarea_rows' => 4,
						'teeny'         => true,
						'media_buttons' => false,
					),
				),
				/*
				// SELECT ADVANCED BOX
				array(
					'name'        => esc_html__( 'Select', 'your-prefix' ),
					'id'          => 'col3',
					'type'        => 'select_advanced',
					// Array of 'value' => 'Label' pairs for select box
					'options'     => array(
						'value1' => esc_html__( 'Label1', 'your-prefix' ),
						'value2' => esc_html__( 'Label2', 'your-prefix' ),
					),
					// Select multiple values, optional. Default is false.
					'multiple'    => false,
					'std'         => 'value2', // Default value, optional
					'placeholder' => esc_html__( 'Select an Item', 'your-prefix' ),
				),*/
				/*
				// AUTOCOMPLETE
				array(
					'name'    => esc_html__( 'Autocomplete', 'your-prefix' ),
					'id'      => 'col3',
					'type'    => 'autocomplete',
					// Options of autocomplete, in format 'value' => 'Label'
					'options' => array(
						'value1' => esc_html__( 'Label1', 'your-prefix' ),
						'value2' => esc_html__( 'Label2', 'your-prefix' ),
					),
					// Input size
					'size'    => 30,
					// Clone?
					'clone'   => false,
				),*/
				// SELECT BOX
				/*
				array(
					'name'        => esc_html__( 'Select', 'your-prefix' ),
					'id'          => 'col3',
					'type'        => 'select',
					// Array of 'value' => 'Label' pairs for select box
					'options'     => array(
						'value1' => esc_html__( 'Label1', 'your-prefix' ),
						'value2' => esc_html__( 'Label2', 'your-prefix' ),
					),
					// Select multiple values, optional. Default is false.
					'multiple'    => false,
					'std'         => 'value2',
					'placeholder' => esc_html__( 'Select an Item', 'your-prefix' ),
				),*/
				/*
				array(
					'name'    => esc_html__( 'Radio', 'your-prefix' ),
					'id'      => 'col3',
					'type'    => 'radio',
					'std'     => 'value2',
					// Array of 'value' => 'Label' pairs for radio options.
					// Note: the 'value' is stored in meta field, not the 'Label'
					'options' => array(
						'value1' => esc_html__( 'Label1', 'your-prefix' ),
						'value2' => esc_html__( 'Label2', 'your-prefix' ),
					),
				),*/
				/*
				array(
					'name' => esc_html__( 'Checkbox', 'your-prefix' ),
					'id'   => 'col3',
					'type' => 'checkbox',
					'std'  => 1,
				),*/
			),
		);

		$meta_boxes[] = array(
			'post_types'   => 'page',
			'title'        => 'Test custom table 2',
			'storage_type' => 'custom_table',
			'table'        => 'wp_test',
			'fields'       => array(
				array(
					'name' => 'Col 1',
					'id'   => 'col1',
					'type' => 'text',
				),
				array(
					'name' => 'Col 2',
					'id'   => 'col2',
					'type' => 'text',
					'std'  => 'Col 2 default value',
				),
				// WYSIWYG/RICH TEXT EDITOR
				array(
					'name'    => esc_html__( 'WYSIWYG / Rich Text Editor', 'your-prefix' ),
					'id'      => 'col3',
					'type'    => 'wysiwyg',
					// Set the 'raw' parameter to TRUE to prevent data being passed through wpautop() on save
					'raw'     => false,
					'std'     => esc_html__( 'WYSIWYG default value', 'your-prefix' ),

					// Editor settings, see wp_editor() function: look4wp.com/wp_editor
					'options' => array(
						'textarea_rows' => 4,
						'teeny'         => true,
						'media_buttons' => false,
					),
				),
			),
		);

		return $meta_boxes;
	}
);
