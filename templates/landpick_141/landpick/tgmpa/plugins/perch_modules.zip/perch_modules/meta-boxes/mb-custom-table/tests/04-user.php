<?php
/**
 * This file tests custom table for saving user meta.
 *
 * @package    Meta Box
 * @subpackage MB Custom Table
 */

add_action(
	'init',
	function () {
		if ( ! class_exists( 'MB_Custom_Table_API' ) ) {
			return;
		}
		MB_Custom_Table_API::create(
			'wp_user_test',
			array(
				'text'           => 'TEXT NOT NULL',
				'checkbox'       => 'TEXT NOT NULL',
				'radio'          => 'TEXT NOT NULL',
				'select'         => 'TEXT NOT NULL',
				'textarea'       => 'TEXT NOT NULL',
				'checkbox_list'  => 'TEXT NOT NULL',
				'taxonomy_adv'   => 'TEXT NOT NULL',
				'file_advanced'  => 'TEXT NOT NULL',
				'image_advanced' => 'TEXT NOT NULL',
				'user'           => 'TEXT NOT NULL',
				'file'           => 'TEXT NOT NULL',
			)
		);
	}
);

add_filter(
	'rwmb_meta_boxes',
	function ( $meta_boxes ) {
		$meta_boxes[] = array(
			'title'        => 'Test field types for custom table',
			'storage_type' => 'custom_table',
			'table'        => 'wp_user_test',
			'type'         => 'user',
			'fields'       => array(
				array(
					'name' => 'Text',
					'id'   => 'text',
					'type' => 'text',
				),
				array(
					'name' => esc_html__( 'Checkbox', 'your-prefix' ),
					'id'   => 'checkbox',
					'type' => 'checkbox',
				),
				array(
					'name'    => esc_html__( 'Radio', 'your-prefix' ),
					'id'      => 'radio',
					'type'    => 'radio',
					'options' => array(
						'value1' => esc_html__( 'Label1', 'your-prefix' ),
						'value2' => esc_html__( 'Label2', 'your-prefix' ),
					),
					'clone'   => true,
				),
				array(
					'name'        => esc_html__( 'Select', 'your-prefix' ),
					'id'          => 'select',
					'type'        => 'select',
					'options'     => array(
						'value1' => esc_html__( 'Label1', 'your-prefix' ),
						'value2' => esc_html__( 'Label2', 'your-prefix' ),
					),
					'multiple'    => false,
					'std'         => 'value2',
					'placeholder' => esc_html__( 'Select an Item', 'your-prefix' ),
				),
				array(
					'name' => esc_html__( 'Textarea', 'your-prefix' ),
					'desc' => esc_html__( 'Textarea description', 'your-prefix' ),
					'id'   => 'textarea',
					'type' => 'textarea',
					'cols' => 20,
					'rows' => 3,
				),
				array(
					'name'    => esc_html__( 'Checkbox list', 'your-prefix' ),
					'id'      => 'checkbox_list',
					'type'    => 'checkbox_list',
					'options' => array(
						'value1' => esc_html__( 'Label1', 'your-prefix' ),
						'value2' => esc_html__( 'Label2', 'your-prefix' ),
						'value3' => esc_html__( 'Label3', 'your-prefix' ),
					),
				),
				[
					'name'     => 'Taxonomy Advanced',
					'id'       => 'taxonomy_adv',
					'type'     => 'taxonomy_advanced',
					'taxonomy' => 'category',
				],
				[
					'name' => 'File Advanced',
					'id'   => 'file_advanced',
					'type' => 'file_advanced',
				],
				[
					'name' => 'Image Advanced',
					'id'   => 'image_advanced',
					'type' => 'image_advanced',
				],
				[
					'name' => 'User',
					'id'   => 'user',
					'type' => 'user',
				],
				[
					'name' => 'File',
					'id'   => 'file',
					'type' => 'file',
				],
			),
		);

		return $meta_boxes;
	}
);
