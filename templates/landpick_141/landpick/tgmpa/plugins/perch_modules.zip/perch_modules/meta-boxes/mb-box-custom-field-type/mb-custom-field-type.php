<?php
/**
 * Plugin Name: Meta Box Custom Field Type
 * Plugin URI: http://themeperch.net
 * Description: Meta Box Custom Fields Type
 * Version: 1.0.0
 * Author: WP Knifer
 * Author URI: http://themeperch.net
 * License: GPL2+
 *
 * @package    Meta Box
 * @subpackage Meta Box Custom Field Type
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'MB_Custom_Field_Type' ) ) {


	class MB_Custom_Field_Type {
		/**
		 * Add hooks when class is loaded
		 */
		public function __construct() {
			add_action( 'init', array( $this, 'load_files' ) );			
		}

		public function load_files(){			
			
			foreach ( glob( __DIR__ . "/fields/class*.php" ) as $filename ) {
			    if( file_exists($filename) ){
			        require_once $filename;
			    }    
			}				
			
		}
		
	}

	new MB_Custom_Field_Type();
}