const $ = jQuery;
const i18n = MBUP_Data;

// Set ajax URL for ajax actions like query images for image_advanced fields.
if ( ! window.ajaxurl ) {
	window.ajaxurl = i18n.ajaxUrl;
}

const checkRecaptcha = ( { success, error } ) => {
	grecaptcha.ready( () => grecaptcha.execute( i18n.recaptchaKey, { action: 'submit_profile' } ).then( success ).catch( error ) );
}

// Save editor content for ajax submission.
function saveEditorContent() {
	var id = $( this ).attr( 'id' );

	$( document ).on( 'tinymce-editor-init', ( event, editor ) => {
		editor.on( 'input keyup', () => editor.save() );
	} );
}

$( function() {
	$( '.rwmb-wysiwyg' ).each( saveEditorContent );
} );

export { checkRecaptcha };