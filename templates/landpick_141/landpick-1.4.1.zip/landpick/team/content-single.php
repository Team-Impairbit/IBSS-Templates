<div id="post-<?php the_ID(); ?>" <?php post_class('wow fadeInUp'); ?>  data-wow-delay="0.1s">
	
	<?php the_content(); ?>

</div>	<!-- END BLOG POST #post-<?php the_ID(); ?> -->