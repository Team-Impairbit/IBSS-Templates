<?php
include LANDPICK_DIR . '/admin/iconpicker/pixden-icons.php'; 
include LANDPICK_DIR . '/admin/iconpicker/tons-icons.php'; 
include LANDPICK_DIR . '/admin/iconpicker/flat-icons.php'; 
