<ul class="navbar-text">	
	<?php echo LandpickHeader::get_navbar_icon_elements(); ?>
</ul><!-- Header Social Icons -->					      	
