<a class="image-link" href="<?php the_post_thumbnail_url( 'full' ); ?>"><?php the_post_thumbnail( 'landpick-700x700-crop', array('class' => 'img-fluid m-bottom-10') );  ?></a><!-- Image -->
