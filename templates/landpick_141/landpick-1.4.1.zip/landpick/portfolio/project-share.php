<?php 
	$args = array(
		'wrapclass' => 'share-social-icons clearfix',
		'before' => '<div class="post-share-list">',
		'after' => '</div><!-- POST SHARE ICONS -->',
	);
	landpick_social_share(true, $args);

	

?>