<div id="<?php landpick_container_id(); ?>" <?php landpick_container_class(); ?>>
	<div class="container">
	 	<div class="row">
	 		<!-- BLOG POSTS HOLDER -->
	 		<div class="<?php landpick_content_wrap_class(); ?>">
	 			<div class="posts-holder">