				</div>
	 		</div>	 <!-- END BLOG POSTS HOLDER -->



	 		<?php get_sidebar(); ?>

	 		
	 	</div>	<!-- End row -->	
	 </div>	 <!-- End container -->
</div>	<!-- END BLOG PAGE CONTENT -->