<?php
if( class_exists('PerchVcCarouselMap') ):
	echo apply_filters('perch_vc_carousel', $atts, $content);
endif;	